package prjZoologico;

public class Aplicacaozoo {

	public static void main(String[] args) {
		ClasseAnimais elefante = new ClasseAnimais();
		elefante.setNome("Dumbo");
		elefante.setPeso(100);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		ClasseAnimais girafa = new ClasseAnimais("Mel", "russa", "femea", 100);
		
		SubClasseCarnivoro leao = new SubClasseCarnivoro ();
		leao.atributoNome = "Leãodro";
		leao.atributoEspecie = "Australeandro";
		leao.atributoSexo = "Macho";
		leao.atributoPeso = 123;
		
		SubClasseReptil cobra = new SubClasseReptil();
		cobra.atributoNome= "Ana conda";
		cobra.atributoEspecie = "Anaconda";
		cobra.atributoSexo = "Fêmea";
		cobra.atributoPeso = 200;
		
		
			leao.exibirInfo();
			leao.metodoCacar();
			leao.metodoComer();
			leao.metodoEmitirSom();
			System.out.println("\n");
			
			elefante.exibirInfo();
			elefante.metodoComer(50);
			elefante.exibirInfo();
			elefante.metodoEmitirSom();
			System.out.println("\n");

			girafa.exibirInfo();
			girafa.metodoComer(30);
			girafa.metodoEmitirSom();
			girafa.exibirInfo();
			System.out.println("\n");
			
			cobra.exibirInfo();
			cobra.metodoRastejar();
			cobra.metodoComer();
			cobra.exibirInfo();
			cobra.metodoEmitirSom();
			
	}

}
