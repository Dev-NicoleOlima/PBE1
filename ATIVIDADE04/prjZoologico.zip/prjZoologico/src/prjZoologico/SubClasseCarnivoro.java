package prjZoologico;

public class SubClasseCarnivoro extends ClasseAnimais {
	
	
	//Metodos da SubClasse
	
	public void metodoCacar() {
		System.out.println(this.atributoNome + " Está caçando");
	}
	    @Override
		public void metodoEmitirSom() {
			System.out.println("RUAAAAAAR");
		}
	

}
