package prjZoologico;

public class SubClasseReptil extends ClasseAnimais {
	public void metodoTrocarPele() {
		
		System.out.println(this.getAtributoNome() + " Está trocando de pele");
	}
	
	public void metodoRastejar() {
		System.out.println(this.getAtributoNome() + " Esta rastejando");
	}
	@Override
	public void metodoEmitirSom() {
		System.out.println("sisiiiiiiiiii");
	}
	
	

}



