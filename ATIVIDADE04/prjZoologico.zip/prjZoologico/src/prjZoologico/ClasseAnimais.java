package prjZoologico;

public class ClasseAnimais {
	//Atributos
	private String atributoNome;
	private String atributoEspecie;
	private String atributoSexo;
	private double atributoPeso;
	
	//Construtores
	public ClasseAnimais() {
	
	}
		public ClasseAnimais(String parametroNome, String parametroEspecie, String parametroSexo, double parametroPeso) {
				this.atributoNome = parametroNome;
				this.atributoEspecie = parametroEspecie;
				this.atributoSexo = parametroSexo;
				this.atributoPeso = parametroPeso;
				
				
		}
		
		//Metodos  Setters
		public void setNome (String parametroNome) {
			this.atributoNome = parametroNome;
		}
		public void setPeso (double parametroPeso) {
			if (parametroPeso > 0) {
			this.atributoPeso = parametroPeso;
			
		}
			else {
				this.atributoPeso = 10;
			}
		}
		
				public String getAtributoNome() {
					return atributoNome;
				}
				public void setAtributoNome(String atributoNome) {
					this.atributoNome = atributoNome;
				}
				public String getAtributoEspecie() {
					return atributoEspecie;
				}
				public void setAtributoEspecie(String atributoEspecie) {
					this.atributoEspecie = atributoEspecie;
				}
				public String getAtributoSexo() {
					return atributoSexo;
				}
				public void setAtributoSexo(String atributoSexo) {
					this.atributoSexo = atributoSexo;
				}
				public double getAtributoPeso() {
					return atributoPeso;
				}
				public void setAtributoPeso(double atributoPeso) {
					this.atributoPeso = atributoPeso;
				}
			
		
		//Métodos
		public void metodoComer() {
			if (this.atributoPeso >= 170 ) {
				System.out.println(this.atributoNome + " Está obeso, vamos exercitar");
			}
			else {
				this.atributoPeso = this.atributoPeso + 10;
			}
		}
		
		public void metodoComer(int parametroRacao) {
			if (this.atributoPeso >= 170 ) {
		System.out.println(this.atributoNome + " Está obeso, vamos exercitar");
		}
			else {
				this.atributoPeso += parametroRacao;
		}
	      }
		public void metodoExercitar() {
			if (this.atributoPeso <= 50) {
				System.out.println(this.atributoNome + " Que tal se alimenbtar?");
			}
			else {
			this.atributoPeso = this.atributoPeso -=10;
		}
			}
		public void exibirInfo() {
			System.out.println("Nome: " + this.atributoNome);
			System.out.println("Peso: " + this.atributoPeso);
			
		}
		public void metodoEmitirSom() {
			System.out.println("Barulho do bichinho");
			
			}
}