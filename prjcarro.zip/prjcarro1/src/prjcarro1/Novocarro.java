package prjcarro1;

import java.util.Scanner;

public class Novocarro {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Carro carro01 = new Carro();
		Carro carro02 = new Carro("Vw","GOL",0);
		Carro carro03 = new Carro ("Toyota");
		
		
		System.out.println("Qual a marca?");
        carro01.marca = sc.next();
        System.out.println(" Qual o modelo?");
        carro01.modelo = sc.next();
        System.out.println("Qual a velocidade?");
        carro01.velocidade = sc.nextInt();
        System.out.println(" Opções:");
        System.out.println(" 1. Acelerar:");
        System.out.println(" 2. Frear:");
        System.out.println(" 3. Buzinar:");
        int escolha = sc.nextInt();
        
        if (escolha ==1) {
        	System.out.println("quanto vc quer acelerar?");
        	carro01.acelerar(sc.nextInt());
        }
        else if (escolha == 2) {
        	System.out.println("Quanto vc quer desacelerar?");
        	carro01.frear(sc.nextInt());
        }
        else if (escolha == 3) {
        	carro01.buzinar();
        }else {
        	System.out.println("opção inválida");
        }
        System.out.println("Marca: "+ carro01.getMarca());
        System.out.println("Modelo: "+ carro01.getModelo());
        System.out.println("Velocidade: "+ carro01.getVelocidade());
	}
	
}
