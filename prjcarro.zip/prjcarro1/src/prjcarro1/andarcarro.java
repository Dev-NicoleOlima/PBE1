package prjcarro1;

import java.util.Scanner;

public class andarcarro {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner (System.in);
		
		
    System.out.println("Qual a marca do carro?");
     String marcacarro = sc.next();
    System.out.println("Qual o modelo do carro?");
     String modelo = sc.next();
    System.out.println("Qual a velocidade ?");
     int velocidade = sc.nextInt();
    System.out.println("Você quer acelerar ou frear?");
    System.out.println(" Acelerar: digite 1");
    System.out.println(" Frear: digite 2");
     int escolha = sc.nextInt();
     
   
   
     
      if  (velocidade == 1) {
    	 
    	  System.out.println("O quanto você quer acelerar?" );
    	  int qnt = sc.nextInt();
    	  int velot = velocidade += qnt;
    	  System.out.println("A velocidade agora é : " + velot );
    	  
    	  
    	  
    	  
      } else if ( velocidade == 2) {
    	  System.out.println("O quanto você quer frear?");
    	  int qnt = sc.nextInt();
    	  int velot = velocidade -= qnt;
    	  System.out.println(" A velocidade agora é : " + velot);
    	  
    	  
    	  
      }else {
    	  System.out.println("resposta inválida");
      }
      
	
	
	
	
	}

}