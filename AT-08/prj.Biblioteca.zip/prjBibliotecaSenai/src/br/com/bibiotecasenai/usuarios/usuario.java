package br.com.bibiotecasenai.usuarios;

public class usuario extends Pessoa{
	private int CPF;
	private int Livroemprestados;
	private String adicionarLivro;
	private String removerLivro;
	//metodos
	public int getCPF() {
		return CPF;
	}
	public void setCPF(int cPF) {
		CPF = cPF;
	}
	public int getLivroemprestados() {
		return Livroemprestados;
	}
	public void setLivroemprestados(int livroemprestados) {
		Livroemprestados = livroemprestados;
	}
	public String getAdicionarLivro() {
		return adicionarLivro;
	}
	public void setAdicionarLivro(String adicionarLivro) {
		this.adicionarLivro = adicionarLivro;
	}
	public String getRemoverLivro() {
		return removerLivro;
	}
	public void setRemoverLivro(String removerLivro) {
		this.removerLivro = removerLivro;
	}
	
	

}
