package br.com.bibiotecasenai.principal;

import br.com.bibiotecasenai.usuarios.usuario;

class Emprestimo {
     int numeroEmprestimo;

    public Emprestimo(int numeroEmprestimo) {
        this.numeroEmprestimo = numeroEmprestimo;
    }

    public void emprestarLivro(Livro livro, usuario usuario) {
        usuario.setLivroemprestados(usuario.getLivroemprestados()+1); 
    }

    public void devolverLivro(Livro livro, usuario usuario) {
         usuario.setLivroemprestados(usuario.getLivroemprestados()-1) ;
           
        }
    }

