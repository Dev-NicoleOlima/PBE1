package br.com.bibiotecasenai.principal;

public class Livro  {
	private String titulo;
	private String autot;
	private String ISBN;
	private boolean disponivel;
	
	
	//metodos
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getAutot() {
		return autot;
	}
	public void setAutot(String autot) {
		this.autot = autot;
	}
	public String getISBN() {
		return ISBN;
	}
	public void setISBN(String iSBN) {
		ISBN = iSBN;
	}
	public boolean isDisponivel() {
		return disponivel;
	}
	public void setDisponivel(boolean disponivel) {
		this.disponivel = disponivel;
	}
	
	

}
