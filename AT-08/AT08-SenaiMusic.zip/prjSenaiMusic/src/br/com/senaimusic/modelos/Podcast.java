package br.com.senaimusic.modelos;

public class Podcast extends Audio {
	// atributos
	private String apresentador;
	private String descricao;
	
	// getters e setters
	public String getapresentador() {
		return this.apresentador;
		
	}
	public void setapresentador(String apresentador) {
		this.apresentador = apresentador;
	}
	
	public String getdescricao() {
		return this.descricao;
		
	}
	public void setdescricao(String descricao) {
		this.descricao = descricao;
	}
	@Override
	public double getclassificacao() {
		if (this.gettotalcurtidas() > 500) {
			return 10;
		} else {
			return 8;
		}
		
	}
	
	

}
