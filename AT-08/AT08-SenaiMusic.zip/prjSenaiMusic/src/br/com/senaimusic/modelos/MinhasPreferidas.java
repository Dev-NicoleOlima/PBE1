package br.com.senaimusic.modelos;

public class MinhasPreferidas {

	public void incluir(Audio audio) {
		if(audio.getclassificacao() >= 9) {
			System.out.println("Essa é top");
			
		} else {
			System.out.println("Essa nem tanto.");
		}
		
		
	}
} 

