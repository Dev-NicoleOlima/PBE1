package br.com.senaimusic.modelos;

public class Audio {
	// atributos
	private String titulo;
	private int totalReproducoes;
	private int totalcurtidas;
	private double classificacao;

	// construtores
	public Audio() {

	}

	public Audio(String titulo) {
		this.titulo = titulo;
		this.totalcurtidas = 0;
		this.totalReproducoes = 0;
		this.classificacao = 0;

	}

	// Getters e Setters
		public void settitulo (String titulo) {
		this.titulo = titulo;
		}
		
		public String gettitulo() {
			return this.titulo;
		}
		public int gettotalReproducoes() {
			return this.totalReproducoes;
		}
		public int gettotalcurtidas() {
			return this.totalcurtidas;
		}
		public double getclassificacao() {
			return this.classificacao;
		}
		
		
	// metodos
	public void curte() {
		this.totalcurtidas++;
	}

	public void reproduzir() {
		this.totalReproducoes++;
	}

}
