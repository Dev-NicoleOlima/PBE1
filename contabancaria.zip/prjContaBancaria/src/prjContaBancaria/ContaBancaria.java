package prjContaBancaria;

import java.util.Scanner;

public class ContaBancaria {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		 System.out.println("Qual o número da conta bancária?");
		 int num = sc.nextInt();
		 System.out.println("Nome do titular da conta: ");
		 String nome = sc.next();
		 System.out.println("Saldo atual da conta: ");
		 double saldo = sc.nextDouble();
		 
		 
	}

}
