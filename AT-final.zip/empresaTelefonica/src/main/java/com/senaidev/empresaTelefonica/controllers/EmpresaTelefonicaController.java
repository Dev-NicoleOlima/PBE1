package com.senaidev.empresaTelefonica.controllers;

public class EmpresaTelefonicaController {

}
