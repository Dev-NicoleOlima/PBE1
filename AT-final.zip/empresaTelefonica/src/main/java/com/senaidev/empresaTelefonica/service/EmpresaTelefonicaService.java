package com.senaidev.empresaTelefonica.service;

public class EmpresaTelefonicaService {

}
