package com.senaidev.empresaTelefonica.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.senaidev.empresaTelefonica.entities.Telefone;

@Repository
public interface ClienteRepository extends JpaRepository<Telefone, Long> {
	

}
