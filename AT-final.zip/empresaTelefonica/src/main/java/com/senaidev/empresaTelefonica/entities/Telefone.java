package com.senaidev.empresaTelefonica.entities;

public class Telefone {
	

}
